package com.example.myapplication;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class Gracz implements Parcelable {
    private String nazwa;
    private final ArrayList<Integer> gdzieJegoZnaki = new ArrayList<>(9);
    private int obecnyIndex;
    private boolean czyTwojaTura;
    private final TextView tekstWygrana;
    private final Context context;
    private boolean koniecGry = false;
    private static int iloscUzyc = 0;
    private String wynik;
    private boolean wygrany;

    public String getNazwa() {
        return nazwa;
    }

    public Gracz(String nazwa,boolean takczynie,TextView tekst,Context context) {
        this.nazwa = nazwa;
        this.czyTwojaTura = takczynie;
        this.context = context;
        this.tekstWygrana = tekst;
        gdzieJegoZnaki.add(0);
        gdzieJegoZnaki.add(0);
        gdzieJegoZnaki.add(0);
        gdzieJegoZnaki.add(0);
        gdzieJegoZnaki.add(0);
        gdzieJegoZnaki.add(0);
        gdzieJegoZnaki.add(0);
        gdzieJegoZnaki.add(0);
        gdzieJegoZnaki.add(0);
    }

    public void setCzyTwojaTura(boolean czyTwojaTura) {
        this.czyTwojaTura = czyTwojaTura;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public ArrayList<Integer> getGdzieJegoZnaki() {
        return gdzieJegoZnaki;
    }

    public void setKoniecGry(boolean koniecGry) {
        this.koniecGry = koniecGry;
    }

    public void zaznaczenie(int i, Gracz przeciwnik, Button obecnyButton){
        obecnyIndex = i;
        if(czyTwojaTura && gdzieJegoZnaki.get(obecnyIndex) != 1 && przeciwnik.getGdzieJegoZnaki().get(obecnyIndex) != 1 && !koniecGry) {
            gdzieJegoZnaki.set(i, 1);
            obecnyButton.setText(getNazwa());
            czyTwojaTura = false;
            przeciwnik.setCzyTwojaTura(true);
            iloscUzyc++;
            tekstWygrana.setText(wynik);
            sprawdz();
        }else if((gdzieJegoZnaki.get(obecnyIndex) == 1 || przeciwnik.getGdzieJegoZnaki().get(obecnyIndex)==1) && !koniecGry){
            Toast.makeText(context, "TUTAJ JUZ JEST ZNACZEK", Toast.LENGTH_SHORT).show();
        }
        if(koniecGry){
            przeciwnik.setKoniecGry(true);
            czyTwojaTura = true;
        }
        tekstWygrana.setText(wynik);
    }

    public boolean isCzyTwojaTura() {
        return czyTwojaTura;
    }

    public String getWynik() {
        return wynik;
    }

    public void setIloscUzyc(int iloscUzyc) {
        Gracz.iloscUzyc = iloscUzyc;
    }

    public void sprawdz(){
        if(gdzieJegoZnaki.get(0) == 1 && gdzieJegoZnaki.get(1) == 1 && gdzieJegoZnaki.get(2) == 1){
            wynik= "Wygrał:" + getNazwa();
            tekstWygrana.setText(wynik);
            koniecGry = true;
            wygrany = true;
            iloscUzyc=0;
        }else if(gdzieJegoZnaki.get(3) == 1 && gdzieJegoZnaki.get(4) == 1 && gdzieJegoZnaki.get(5) == 1){
            wynik= "Wygrał:" + getNazwa();
            tekstWygrana.setText(wynik);
            koniecGry = true;
            wygrany = true;
            iloscUzyc=0;
        }else if(gdzieJegoZnaki.get(6) == 1 && gdzieJegoZnaki.get(7) == 1 && gdzieJegoZnaki.get(8) == 1){
            wynik= "Wygrał:" + getNazwa();
            tekstWygrana.setText(wynik);
            koniecGry = true;
            wygrany = true;
            iloscUzyc=0;
        }else if(gdzieJegoZnaki.get(0) == 1 && gdzieJegoZnaki.get(3) == 1 && gdzieJegoZnaki.get(6) == 1){
            wynik= "Wygrał:" + getNazwa();
            tekstWygrana.setText(wynik);
            koniecGry = true;
            wygrany = true;
            iloscUzyc=0;
        }else if(gdzieJegoZnaki.get(1) == 1 && gdzieJegoZnaki.get(4) == 1 && gdzieJegoZnaki.get(7) == 1){
            wynik= "Wygrał:" + getNazwa();
            tekstWygrana.setText(wynik);
            koniecGry = true;
            wygrany = true;
            iloscUzyc=0;
        }else if(gdzieJegoZnaki.get(2) == 1 && gdzieJegoZnaki.get(5) == 1 && gdzieJegoZnaki.get(8) == 1){
            wynik= "Wygrał:" + getNazwa();
            tekstWygrana.setText(wynik);
            koniecGry = true;
            wygrany = true;
            iloscUzyc=0;
        }else if(gdzieJegoZnaki.get(0) == 1 && gdzieJegoZnaki.get(4) == 1 && gdzieJegoZnaki.get(8) == 1){
            wynik= "Wygrał:" + getNazwa();
            tekstWygrana.setText(wynik);
            koniecGry = true;
            wygrany = true;
            iloscUzyc=0;
        }else if(gdzieJegoZnaki.get(2) == 1 && gdzieJegoZnaki.get(4) == 1 && gdzieJegoZnaki.get(6) == 1){
            wynik= "Wygrał:" + getNazwa();
            tekstWygrana.setText(wynik);
            wygrany = true;
            koniecGry = true;
            iloscUzyc=0;
        }else if(iloscUzyc >= 9){
            koniecGry = true;
            iloscUzyc=0;
            wynik= "REMIS";
            tekstWygrana.setText(wynik);
        }
        tekstWygrana.setText(wynik);
    }

    public boolean isWygrany() {
        return wygrany;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {

    }
}
