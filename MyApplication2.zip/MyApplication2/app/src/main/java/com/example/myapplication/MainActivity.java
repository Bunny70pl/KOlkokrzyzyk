package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private Button prz1;
    private Button prz2;
    private Button prz3;
    private Button prz4;
    private Button prz5;
    private Button prz6;
    private Button prz7;
    private Button prz8;
    private Button prz9;
    private Button prz10;
    private TextView tekstView;
    Gracz graczX;
    Gracz graczY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        if (savedInstanceState != null) {
            graczX = savedInstanceState.getParcelable("graczX");
            graczY = savedInstanceState.getParcelable("graczY");
        } else {
            graczX = new Gracz("X", true, findViewById(R.id.textView2), this);
            graczY = new Gracz("O", false, findViewById(R.id.textView2), this);
        }
        tekstView = findViewById(R.id.textView2);
        tekstView.setText(graczX.getWynik());
        if(graczX.isWygrany()){
            tekstView.setText(graczX.getWynik());
        }else if(graczY.isWygrany()){
            tekstView.setText(graczY.getWynik());
        }
        prz1 = findViewById(R.id.button);
        prz2 = findViewById(R.id.button1);
        prz3 = findViewById(R.id.button2);
        prz4 = findViewById(R.id.button3);
        prz5 = findViewById(R.id.button4);
        prz6 = findViewById(R.id.button5);
        prz7 = findViewById(R.id.button6);
        prz8 = findViewById(R.id.button7);
        prz9 = findViewById(R.id.button8);
        prz10 = findViewById(R.id.RESET);
        prz1.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(graczX.isCzyTwojaTura() == true){
                            graczX.zaznaczenie(0,graczY,prz1);
                        }else{
                            graczY.zaznaczenie(0,graczX,prz1);
                        }
                    }
                }
        );
        prz2.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(graczX.isCzyTwojaTura() == true){
                            graczX.zaznaczenie(1,graczY,prz2);
                        }else{
                            graczY.zaznaczenie(1,graczX,prz2);
                        }
                    }
                }
        );
        prz3.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(graczX.isCzyTwojaTura() == true){
                            graczX.zaznaczenie(2,graczY,prz3);
                        }else{
                            graczY.zaznaczenie(2,graczX,prz3);
                        }
                    }
                }
        );
        prz4.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(graczX.isCzyTwojaTura() == true){
                            graczX.zaznaczenie(3,graczY,prz4);
                        }else{
                            graczY.zaznaczenie(3,graczX,prz4);
                        }
                    }
                }
        );
        prz5.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(graczX.isCzyTwojaTura() == true){
                            graczX.zaznaczenie(4,graczY,prz5);
                        }else{
                            graczY.zaznaczenie(4,graczX,prz5);
                        }
                    }
                }
        );
        prz6.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(graczX.isCzyTwojaTura() == true){
                            graczX.zaznaczenie(5,graczY,prz6);
                        }else{
                            graczY.zaznaczenie(5,graczX,prz6);
                        }
                    }
                }
        );
        prz7.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(graczX.isCzyTwojaTura() == true){
                            graczX.zaznaczenie(6,graczY,prz7);
                        }else{
                            graczY.zaznaczenie(6,graczX,prz7);
                        }
                    }
                }
        );
        prz8.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(graczX.isCzyTwojaTura() == true){
                            graczX.zaznaczenie(7,graczY,prz8);
                        }else{
                            graczY.zaznaczenie(7,graczX,prz8);
                        }
                    }
                }
        );
        prz9.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(graczX.isCzyTwojaTura() == true){
                            graczX.zaznaczenie(8,graczY,prz9);
                        }else{
                            graczY.zaznaczenie(8,graczX,prz9);
                        }
                    }
                }
        );
        prz10.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        reset();
                    }
                }
        );

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void reset(){
        graczY.setIloscUzyc(0);
        graczX.setIloscUzyc(0);
        Intent intent = getIntent();
        finish();
        startActivity(intent);

    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("stringprz1", String.valueOf(prz1.getText()));
        outState.putString("stringprz2", String.valueOf(prz2.getText()));
        outState.putString("stringprz3", String.valueOf(prz3.getText()));
        outState.putString("stringprz4", String.valueOf(prz4.getText()));
        outState.putString("stringprz5", String.valueOf(prz5.getText()));
        outState.putString("stringprz6", String.valueOf(prz6.getText()));
        outState.putString("stringprz7", String.valueOf(prz7.getText()));
        outState.putString("stringprz8", String.valueOf(prz8.getText()));
        outState.putString("stringprz9", String.valueOf(prz9.getText()));
        outState.putParcelable("graczX", graczX);
        outState.putParcelable("graczY", graczY);
    }
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        prz1.setText(savedInstanceState.getString("stringprz1"));
        prz2.setText(savedInstanceState.getString("stringprz2"));
        prz3.setText(savedInstanceState.getString("stringprz3"));
        prz4.setText(savedInstanceState.getString("stringprz4"));
        prz5.setText(savedInstanceState.getString("stringprz5"));
        prz6.setText(savedInstanceState.getString("stringprz6"));
        prz7.setText(savedInstanceState.getString("stringprz7"));
        prz8.setText(savedInstanceState.getString("stringprz8"));
        prz9.setText(savedInstanceState.getString("stringprz9"));
    }
}